// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Run unscented update"); }
int main(){
  announce();
  return lionss_run_workload("kalman-unscented");
}
