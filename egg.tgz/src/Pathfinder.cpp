// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Find shortest path"); }
int main(){
  announce();
  return lionss_run_workload("Pathfinder");
}
