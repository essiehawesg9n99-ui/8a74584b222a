// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Autotune PID gains\n", stdout);
  return lionss_run_workload("PidAutotune");
}
